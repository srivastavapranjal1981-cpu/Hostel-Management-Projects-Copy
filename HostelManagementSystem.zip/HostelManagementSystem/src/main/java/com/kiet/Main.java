
import java.sql.*;
import java.util.Scanner;

public class Main {

    static final String URL = "jdbc:mysql://localhost:3306/hostel_db";
    static final String USER = "root";
    static final String PASSWORD = "root";

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);

            System.out.println("Database Connected Successfully!");

            int choice;

            do {
                System.out.println("\n===== HOSTEL MANAGEMENT SYSTEM =====");
                System.out.println("1. Insert Hostel Student Records");
                System.out.println("2. Display Students by Hostel");
                System.out.println("3. Update Hostel Fee");
                System.out.println("4. Search and Update Room");
                System.out.println("5. Display Total Fee and Delete Student");
                System.out.println("6. Exit");

                System.out.print("\nEnter your choice: ");
                choice = Integer.parseInt(sc.nextLine());

                switch (choice) {

                    case 1:
                        insertStudents(con);
                        break;

                    case 2:
                        displayStudents(con);
                        break;

                    case 3:
                        updateFee(con);
                        break;

                    case 4:
                        updateRoom(con);
                        break;

                    case 5:
                        displayTotalAndDelete(con);
                        break;

                    case 6:
                        System.out.println("Thank You!");
                        break;

                    default:
                        System.out.println("Invalid Choice!");
                }

            } while (choice != 6);

            con.close();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // (a) Insert Three Student Records

    static void insertStudents(Connection con) {

        String sql = "INSERT INTO HostelStudent VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            for (int i = 1; i <= 3; i++) {

                System.out.println("\nEnter Student " + i + " Details:");

                System.out.print("Student ID: ");
                int id = Integer.parseInt(sc.nextLine());

                System.out.print("Student Name: ");
                String name = sc.nextLine();

                System.out.print("Roll Number: ");
                String roll = sc.nextLine();

                System.out.print("Hostel Name: ");
                String hostel = sc.nextLine();

                System.out.print("Room Number: ");
                String room = sc.nextLine();

                System.out.print("Hostel Fee: ");
                double fee = Double.parseDouble(sc.nextLine());

                ps.setInt(1, id);
                ps.setString(2, name);
                ps.setString(3, roll);
                ps.setString(4, hostel);
                ps.setString(5, room);
                ps.setDouble(6, fee);

                try {
                    ps.executeUpdate();
                    System.out.println("Student Inserted Successfully!");

                } catch (SQLIntegrityConstraintViolationException e) {
                    System.out.println("Duplicate Student ID!");
                }
            }

        } catch (SQLException e) {
            System.out.println("Insertion Error: " + e.getMessage());
        }
    }

    // (b) Conditional Retrieval and Sorting

    static void displayStudents(Connection con) {

        System.out.print("Enter Hostel Name: ");
        String hostel = sc.nextLine();

        String sql = "SELECT * FROM HostelStudent WHERE hostel_name = ? " +
                "AND fee > 50000 ORDER BY fee DESC";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, hostel);

            try (ResultSet rs = ps.executeQuery()) {

                boolean found = false;

                while (rs.next()) {

                    found = true;

                    System.out.println("\nStudent ID: " + rs.getInt("student_id"));
                    System.out.println("Student Name: " + rs.getString("student_name"));
                    System.out.println("Roll Number: " + rs.getString("roll_number"));
                    System.out.println("Hostel Name: " + rs.getString("hostel_name"));
                    System.out.println("Room Number: " + rs.getString("room_number"));
                    System.out.println("Fee: " + rs.getDouble("fee"));
                }

                if (!found) {
                    System.out.println("No Matching Students Found!");
                }
            }

        } catch (SQLException e) {
            System.out.println("Retrieval Error: " + e.getMessage());
        }
    }

    // (c) Update Hostel Fee

    static void updateFee(Connection con) {

        System.out.print("Enter Student ID: ");
        int id = Integer.parseInt(sc.nextLine());

        System.out.print("Enter New Hostel Fee: ");
        double fee = Double.parseDouble(sc.nextLine());

        String sql = "UPDATE HostelStudent SET fee = ? WHERE student_id = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDouble(1, fee);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Hostel Fee Updated Successfully!");
            } else {
                System.out.println("Student Record Does Not Exist!");
            }

        } catch (SQLException e) {
            System.out.println("Update Error: " + e.getMessage());
        }
    }

    // (d) Search and Modify Room Number

    static void updateRoom(Connection con) {

        System.out.print("Enter Student ID: ");
        int id = Integer.parseInt(sc.nextLine());

        String searchSql = "SELECT * FROM HostelStudent WHERE student_id = ?";

        try (PreparedStatement ps = con.prepareStatement(searchSql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    System.out.println("\n===== STUDENT DETAILS =====");

                    System.out.println("Student Name: " + rs.getString("student_name"));
                    System.out.println("Roll Number: " + rs.getString("roll_number"));
                    System.out.println("Hostel Name: " + rs.getString("hostel_name"));
                    System.out.println("Old Room Number: " + rs.getString("room_number"));

                    System.out.print("Enter New Room Number: ");
                    String room = sc.nextLine();

                    String updateSql =
                            "UPDATE HostelStudent SET room_number = ? WHERE student_id = ?";

                    try (PreparedStatement updatePs =
                                 con.prepareStatement(updateSql)) {

                        updatePs.setString(1, room);
                        updatePs.setInt(2, id);

                        updatePs.executeUpdate();

                        System.out.println("\nRoom Updated Successfully!");
                        System.out.println("Student ID: " + id);
                        System.out.println("Student Name: " + rs.getString("student_name"));
                        System.out.println("New Room Number: " + room);
                        System.out.println("Hostel Fee: " + rs.getDouble("fee"));
                    }

                } else {
                    System.out.println("Student Record Does Not Exist!");
                }
            }

        } catch (SQLException e) {
            System.out.println("Room Update Error: " + e.getMessage());
        }
    }

    // (e) Aggregate Query and Conditional Deletion

    static void displayTotalAndDelete(Connection con) {

        String sql = "SELECT SUM(fee) AS total_fee FROM HostelStudent";

        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) {
                System.out.println("\nTotal Hostel Fee Collected: Rs. "
                        + rs.getDouble("total_fee"));
            }

        } catch (SQLException e) {
            System.out.println("Aggregate Error: " + e.getMessage());
        }

        System.out.print("\nEnter Student ID to Delete: ");
        int id = Integer.parseInt(sc.nextLine());

        String deleteSql =
                "DELETE FROM HostelStudent WHERE student_id = ? AND fee > 0";

        try (PreparedStatement ps = con.prepareStatement(deleteSql)) {

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Student Deleted Successfully!");
            } else {
                System.out.println("Record Cannot Be Deleted! Student Not Found or Fee Not Paid.");
            }

        } catch (SQLException e) {
            System.out.println("Deletion Error: " + e.getMessage());
        }
    }
}
