package com.kiet.controller;

import com.kiet.entity.HostelStudent;
import com.kiet.repository.HostelStudentRepository;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hostel-students")
public class HostelStudentController {

    private final HostelStudentRepository repository;

    public HostelStudentController(HostelStudentRepository repository) {
        this.repository = repository;
    }

    // Add Student
    @PostMapping
    public ResponseEntity<HostelStudent> addStudent(
            @RequestBody HostelStudent student) {

        HostelStudent savedStudent = repository.save(student);

        return new ResponseEntity<>(
                savedStudent, HttpStatus.CREATED);
    }

    // Get All Students
    @GetMapping
    public List<HostelStudent> getAllStudents() {
        return repository.findAll();
    }

    // Get Student By ID
    @GetMapping("/{id}")
    public ResponseEntity<HostelStudent> getStudentById(
            @PathVariable Integer id) {

        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Update Hostel Name, Room Number and Fee
    @PutMapping("/{id}")
    public ResponseEntity<HostelStudent> updateStudent(
            @PathVariable Integer id,
            @RequestBody HostelStudent details) {

        return repository.findById(id)
                .map(student -> {

                    student.setHostelName(details.getHostelName());
                    student.setRoomNumber(details.getRoomNumber());
                    student.setFee(details.getFee());

                    HostelStudent updatedStudent =
                            repository.save(student);

                    return ResponseEntity.ok(updatedStudent);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Delete Student
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStudent(
            @PathVariable Integer id) {

        if (!repository.existsById(id)) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("Student not found");
        }

        repository.deleteById(id);

        return ResponseEntity.ok(
                "Student deleted successfully");
    }
}