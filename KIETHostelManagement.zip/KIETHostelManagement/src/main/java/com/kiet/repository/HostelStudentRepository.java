package com.kiet.repository;

import com.kiet.entity.HostelStudent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HostelStudentRepository
        extends JpaRepository<HostelStudent, Integer> {

}