package com.kiet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KIETHostelManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(KIETHostelManagementApplication.class, args);
    }
}